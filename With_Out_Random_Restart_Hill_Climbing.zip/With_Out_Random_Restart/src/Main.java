


/**
 *
 * @author TURJO-T86
 */


import java.util.Random;
public class Main {

  
    public static void main(String[] args) {
        State solution = Main.greedy_hill_climbing(8);
        System.out.println("Solution"+solution);
    }

    public static State greedy_hill_climbing(int n) {

        int flag=0;
        int currentObjVal;

        State.init_board_size(n);

        State currentState = State.get_random_state();
        System.out.println("<->"+currentState);
         
        currentState = currentState.get_best_successor();
        currentObjVal = currentState.objective_function();

        while (true) {
            System.out.println("Current State : " + currentState);
            System.out.println("---------------------------------------------------");
            System.out.println("---------------------------------------------------");
            System.out.println("Current State Objective Function Value : " + currentObjVal);
            System.out.println("---------------------------------------------------");
            System.out.println("---------------------------------------------------");

            

        }
    

      //  return currentState;
    
    }

   
    
    
   
    
    
    
    
 }
