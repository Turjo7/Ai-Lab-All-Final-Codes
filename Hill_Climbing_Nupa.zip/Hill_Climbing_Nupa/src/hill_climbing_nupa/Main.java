
package hill_climbing_nupa;

/**
 *
 * @author TURJO-T86
 */



public class Main {

  
    public static void main(String[] args) {
        State solution = Main.random_restart_hill_climbing(8);
        System.out.println(solution);
    }

    public static State greedy_hill_climbing(int n) {

        int flag=0;
        int currentObjVal;

        State.init_board_size(n);

        State currentState = State.get_random_state();
         
        currentState = currentState.get_best_successor();
        currentObjVal = currentState.objective_function();

        while (true) {
            System.out.println("Current State : " + currentState);
            System.out.println("---------------------------------------------------");
            System.out.println("---------------------------------------------------");
            System.out.println("Current State Objective Function Value : " + currentObjVal);
            System.out.println("---------------------------------------------------");
            System.out.println("---------------------------------------------------");

            if (currentObjVal == 0 || flag>1) {
                break;
            }
            else {
                flag++;
            }

        }

        return currentState;
    }

    public static State random_restart_hill_climbing(int n) {
        int count=0;

        System.out.println("Calling Random Restart Hill Climbing");
        System.out.println("---------------------------------------------------");
        System.out.println("---------------------------------------------------");

        State endState = null;

        while (true) {
            count++;
            System.out.println("Starting New Random Restart Hill Climbing");
            System.out.println("---------------------------------------------------");
            System.out.println("---------------------------------------------------");
            endState = greedy_hill_climbing(n);

            if (endState.objective_function() == 0) {
                break;
            }
        }
        System.out.println(count);
        return endState;
    }

}
