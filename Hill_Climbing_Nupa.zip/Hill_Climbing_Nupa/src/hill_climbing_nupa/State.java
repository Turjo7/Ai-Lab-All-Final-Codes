
package hill_climbing_nupa;

/**
 *
 * @author TURJO-T86
 */

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class State implements Serializable {

    static int n;
  
    int[] r;

    public static void init_board_size(int size) {
        n = size;
    }

    public State() {
        r = new int[n];
    }

    public int objective_function() {

        int clash = 0;

        for (int i = 0; i < n; ++i) {
            for (int j = i + 1; j < n; ++j) {
                if (r[i] == r[j] || Math.abs(r[i] - r[j]) == Math.abs(i - j)) {
                    clash++;
                }
            }
        }

        return clash;
    }

  
    
    
    
    
    public ArrayList<State> get_successors() {
		ArrayList<State> successors = new ArrayList<>();

		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j)
				if (j != r[i]) {
					State s = new State();

					for (int k = 0; k < n; ++k)
						s.r[k] = r[k];

					s.r[i] = j;

					successors.add(s);
				}
		}

		return successors;
	}
    
    
    
    
    
    
    
    
    public State get_best_successor() {
		int bestVal = Integer.MAX_VALUE;
		State best = new State();

		ArrayList<State> successors = get_successors();

		for (State s : successors) {
			if (bestVal > s.objective_function()) {
				bestVal = s.objective_function();
				best = s;
			}
		}

		return best;
	}
    
    
    
    
    
    

    public static State get_random_state() {
        State state = new State();

        Random random = new Random();
        for (int i=0;i<n;i++){
            state.r[i] = Math.abs(random.nextInt()%n);
        }
       
        
        return state;
    }

    public String toString() {
        return Arrays.toString(r);
    }
}

