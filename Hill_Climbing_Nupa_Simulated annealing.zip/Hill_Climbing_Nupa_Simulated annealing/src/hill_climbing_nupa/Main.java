
package hill_climbing_nupa;

/**
 *
 * @author TURJO-T86
 */


import java.util.Random;
public class Main {

  
    public static void main(String[] args) {
        State solution = Main.random_restart_hill_climbing(8);
        System.out.println("Solution"+solution);
    }

    public static State greedy_hill_climbing(int n) {

        int flag=0;
        int currentObjVal;

        State.init_board_size(n);

        State currentState = State.get_random_state();
        System.out.println("<->"+currentState);
         
        currentState = currentState.get_best_successor();
        currentObjVal = currentState.objective_function();

        while (true) {
            System.out.println("Current State : " + currentState);
            System.out.println("---------------------------------------------------");
            System.out.println("---------------------------------------------------");
            System.out.println("Current State Objective Function Value : " + currentObjVal);
            System.out.println("---------------------------------------------------");
            System.out.println("---------------------------------------------------");

            if (currentObjVal == 0 || flag>1) {
                break;
            }
            else {
                flag++;
            }

        }

        return currentState;
    }

    public static State random_restart_hill_climbing(int n) {
        int count=0;

        System.out.println("Calling Random Restart Hill Climbing");
        System.out.println("---------------------------------------------------");
        System.out.println("---------------------------------------------------");

        State endState = null;

        while (true) {
            count++;
            System.out.println("Starting New Random Restart Hill Climbing");
            System.out.println("---------------------------------------------------");
            System.out.println("---------------------------------------------------");
            endState = greedy_hill_climbing(n);

            if (endState.objective_function() == 0) {
                break;
            }
        }
        System.out.println(count);
        return endState;
    }
    
    
    public static State simulated_annealing()
	{
		State currentState = State.get_random_state();
		double T = 10000;
		double alpha = 0.99;
		Random random = new Random();
		double epsilon = .00001;
		while (T >= epsilon) {
			System.out.println(currentState.objective_function());
			if (currentState.objective_function()==0)
				break;
			
			State neighbor = currentState.get_random_state();
			int currVal = currentState.objective_function();
			int neighborObj = neighbor.objective_function();
			int obj_difference = neighborObj - currVal;
			if (obj_difference < 0)
				currentState = neighbor;
			else {
				double p = Math.exp(-obj_difference / T);
				double randomVal = random.nextDouble();
				if (randomVal <= p)
					currentState = neighbor;
			}
			T = alpha * T;
		}
		return currentState;
	}
    
    
    
    
 }
