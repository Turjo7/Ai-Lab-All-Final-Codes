/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eight_queens;
import java.lang.reflect.Array;
import java.util.ArrayList;
/**
 *
 * @author TURJO-T86
 */
public class Or_Opt{

    public static Route apply(Route rt) {
        Route route1 = new Route(rt);
        rt.updateCost();
        //System.out.println(rt.getCost());

        int length = rt.n;

        for(int chain_size=3; chain_size>=1;chain_size--){
            for(int i=0; i+chain_size-1 < length; i++){
                Route chain = new Route(rt);
                Route temp = new Route(rt);

                chain.route.clear();
                //System.out.println(rt.route.subList(i,i+chain_size));

                chain.route.addAll(rt.route.subList(i,i+chain_size));
                //chain.print();
                temp.route.removeAll(chain.route);
                //temp.print();

                int tempSize = temp.route.size();
                //System.out.println(tempSize);

                for(int j=0; j<tempSize; j++){      //should be zero (first index of arraylist)
                    route1.route.clear();
                    route1.route.addAll(temp.route);
                    route1.route.addAll(j,chain.route);
                    route1.updateCost();
                    //route1.print();
                    //System.out.println(route1.getCost());

                    if(route1.getCost() < rt.getCost()){
                        return route1;
                    }
                }
            }
        }


        return route1;
    }

    public static Route OrOptSwap(Route routeObject, int i, int k) {
        Route route1 = new Route (routeObject);

        return route1;

    }
}
