/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eight_queens;

/**
 *
 * @author TURJO-T86
 */


import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		State.n = 8;

		State end = LocalSearch.random_restart_HCS();
		
		//System.out.println("End");
		System.out.println(end);
		//System.out.println(end.goal_test());

		System.out.println("Total Hill Climbing Called ="+LocalSearch.sum);
	}
}