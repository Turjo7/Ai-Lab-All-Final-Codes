/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eight_queens;

/**
 *
 * @author TURJO-T86
 */
public class LocalSearch {
	static int sum=0;
	public static State greedy_HCS() {

		int count_hcs=0;


		State current = State.get_random_state();

		while (true) {
		System.out.println(current + " Number Of Clash\t" +
							current.objecive());
			
			if (current.goal_test())
				break;

			State bestSuccessor = current.get_best_successor();

			if (bestSuccessor.objecive() < current.objecive()) {
				current = bestSuccessor;
			} else
				break;
			count_hcs++;
		}
		sum+=count_hcs;
		//System.out.println("Greedy HCS="+sum);

		return current;
	}
	
	public static State random_restart_HCS()
	{
		int count=0;
		State soln = null;
		while (true)
		{
			soln=greedy_HCS();
			if(soln.goal_test())
				break;
             count++;
		}

		//System.out.println("\nRandom Greedy call="+count);
		
		return soln;
	}
}

