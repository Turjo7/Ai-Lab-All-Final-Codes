/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eight_queens;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

/**
 *
 * @author TURJO-T86
 */
public class Route {
    ArrayList<Integer> route;
    int n;
    double cost;
    TSP tsp;


    public Route(TSP tsp){
        this.n = tsp.n;
        this.tsp = tsp;
        route = new ArrayList<Integer>();

        initialize();
        this.cost = updateCost();
    }


    public Route(Route src){
        this.n = src.n;
        this.tsp = src.tsp;

        route = new ArrayList<Integer>();

        for (Iterator iterator = src.route.iterator(); iterator.hasNext();) {
            route.add((Integer)iterator.next());
        }

        this.cost = updateCost();
    }



    public void initialize() {
        for (int i = 0; i < n; i++) {
            route.add(i);
        }

        Collections.shuffle(route);
    }


    public void print() {
        for (Iterator iterator = route.iterator(); iterator.hasNext();) {
            System.out.print(iterator.next() + " ");
        }

        System.out.println();
    }


    public double updateCost() {
        cost = 0;

        int m = route.get(0);
        //System.out.println(x1);

        for (int i = 1; i < n; i++) {
            int k = route.get(i);
            cost = cost + Math.sqrt(Math.pow(tsp.x[m]-tsp.x[k],2) + Math.pow(tsp.y[m]-tsp.y[k],2));
            m = k;
        }

        //System.out.println(cost);

        return cost;
    }

    public double getCost() {

        return cost;
    }

}

