/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eight_queens;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;


/**
 *
 * @author TURJO-T86
 */
public class OneOneExchange{
    private static Random random = new Random(System.currentTimeMillis());

    public static Route apply(Route rt){

        Route route = new Route(rt);
        int rnd1, rnd2;

        rnd1 = random.nextInt(route.n);

        do{
            rnd2 = random.nextInt(route.n);
        }while (rnd1==rnd2);

        Collections.swap(route.route, rnd1, rnd2);

        //route.print();
        //System.out.println(rnd1 + " " + rnd2);

        route.updateCost();

        return route;

    }
}