/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TURJO-T86
 */
import java.util.Objects;

public class State {
	int board[][], blankRow, blankCol;

	public State(int[][] board) {
		super();
		this.board = board;

		search_blank();
	}

	public void search_blank(){
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (board[i][j] == 0) {
                    blankRow = i;
                    blankCol = j;

                    return;
                }
            }
        }
    }

	public State move_up() {

		if (blankRow == 0)
			return null;

		int newBoard[][] = new int[3][3];

		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j)
				newBoard[i][j] = board[i][j];

		int temp = newBoard[blankRow][blankCol];
		newBoard[blankRow][blankCol] = newBoard[blankRow - 1][blankCol];
		newBoard[blankRow - 1][blankCol] = temp;

		return new State(newBoard);
	}

	public State move_down() {

		if (blankRow == 2)
			return null;

		int newBoard[][] = new int[3][3];

		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j)
				newBoard[i][j] = board[i][j];

		int temp = newBoard[blankRow][blankCol];
		newBoard[blankRow][blankCol] = newBoard[blankRow + 1][blankCol];
		newBoard[blankRow + 1][blankCol] = temp;

		return new State(newBoard);

        //return null;

	}

	public State move_left() {
        if (blankCol == 0)
			return null;

		int newBoard[][] = new int[3][3];

		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j)
				newBoard[i][j] = board[i][j];

		int temp = newBoard[blankRow][blankCol];
		newBoard[blankRow][blankCol] = newBoard[blankRow][blankCol -1];
		newBoard[blankRow][blankCol - 1] = temp;

		return new State(newBoard);


        //return null;


	}

	public State move_right() {
        if (blankCol == 2)
			return null;

		int newBoard[][] = new int[3][3];

		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j)
				newBoard[i][j] = board[i][j];

		int temp = newBoard[blankRow][blankCol];
		newBoard[blankRow][blankCol] = newBoard[blankRow][blankCol + 1];
		newBoard[blankRow][blankCol + 1] = temp;

		return new State(newBoard);

       // return null;
	}

	public boolean goal_test() {

		if( (board[0][0] == 1) && (board[0][1] == 2) && (board[0][2] == 3)
                && (board[1][0] == 4) && (board[1][1] == 5)&& (board[1][2] == 6)
                 && (board[2][0] == 7)&& (board[2][1] == 8) && (board[2][2] == 0)  ){
            return true;
        }

		return false;
	}

	public String toString() {

		String s = "";

		for (int i = 0; i < 3; ++i) {
			for (int j = 0; j < 3; ++j)
				s += board[i][j] + " ";

			s += "\n";
		}

		return s;
	}

	public int misplacedTiles() {

		int misplacedTilesNumber = 0;

		if(board[0][0] != 1){
			misplacedTilesNumber++;
		}
		if(board[0][1] != 2){
			misplacedTilesNumber++;
		}
		if(board[0][2] != 3){
			misplacedTilesNumber++;
		}
		if(board[1][0] != 4){
			misplacedTilesNumber++;
		}
		if(board[1][1] != 5){
			misplacedTilesNumber++;
		}
		if(board[1][2] != 6){
			misplacedTilesNumber++;
		}
		if(board[2][0] != 7){
			misplacedTilesNumber++;
		}
		if(board[2][1] != 8){
			misplacedTilesNumber++;
		}


		return misplacedTilesNumber;
	}

	public int manDis() {

		int[][] boardF = new int[][]{
  				{ 1, 2, 3 },
  				{ 4, 5, 6 },
				{ 7, 8, 0 }
		};

		int manDisNumb = 0;
		int shouldFound = 0;

		for(int i=0; i<3; i++){
			for(int j=0; j<3; j++){
				int found = board[i][j];
				shouldFound++;

				if((shouldFound != found ) && (found !=0)){
					manDisNumb = manDisNumb + Math.abs(i-getColum(boardF, found))
							+ Math.abs(j-getRow(boardF, found));
				}
			}
		}

		return manDisNumb;
	}


	public int getColum(int [][]board1, int value){
		for(int i=0; i<3; i++){
			for(int j=0; j<3; j++){
				if(value == board1[i][j]){
					return i;
				}
			}
		}
		return -1;

	}

	public int getRow(int [][]board1, int value){
		for(int i=0; i<3; i++){
			for(int j=0; j<3; j++){
				if(value == board1[i][j]){
					return j;
				}
			}
		}
		return -1;

	}


	@Override
	public boolean equals(Object obj) {

		State rhs = (State) obj;

		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j)
				if (board[i][j] != rhs.board[i][j])
					return false;

		return true;
	}

	@Override
	public int hashCode() {

		return Objects
				.hash(board[0][0], board[0][1], board[0][2], board[1][0],
						board[1][1], board[1][2], board[2][0], board[2][1],
						board[2][2]);
	}
}
