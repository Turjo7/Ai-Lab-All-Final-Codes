/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TURJO-T86
 */
import java.util.ArrayList;
import java.util.Collections;

public class Main {
	public static void main(String[] args) {

		 int board[][]=new int[][] {
            {3, 0, 7},
            {2, 8, 1},
            {6, 4, 5}
        };

		State initial = new State(board);
		System.out.println("Board For The First Time Initialize: ");
		System.out.println(initial);

		Node goal = Node.AStarSearch(initial);
                
              
                
                

		if (goal != null) {
			System.out.println("\nSolution:\n");
			Node.print_matrix(goal);
		} else
			System.out.println("No solution found.");
	}

	
}

