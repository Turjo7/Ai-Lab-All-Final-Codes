/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TURJO-T86
 */
import java.util.*;

public class Node{

	State state;
	Node parent;
	int g_n;
        int h_n;
        int f_n;
       

	public Node(State state, Node parent, int g_n,int h_n,int f_n) {
		super();
		this.state = state;
		this.parent = parent;
		this.g_n = g_n;
                this.h_n=h_n;
                this.f_n=f_n;
	}

	public static Node AStarSearch(State initial){

		Node root = new Node(initial, null, 0,0,0);
		//PriorityQueue<Node> queueOfStates = new PriorityQueue<>();
		Queue<Node> queueOfStates = new PriorityQueue<Node>(100, new MyComparator());

		//queueOfStates = new LinkedList<>();
		HashSet<State> closedList = new HashSet<>();

		queueOfStates.add (root);

		while (!queueOfStates.isEmpty()) {

			Node front = queueOfStates.poll();
			State currentState = front.state;

			if (closedList.contains(currentState))
				continue;

			closedList.add(currentState);

			if (currentState.goal_test())
				return front;

			State nextState;
			nextState =  front.state.move_up();
			if (nextState != null)
				queueOfStates.add(new Node(nextState, front,front.g_n+1,front.state.manDis(),((front.g_n)+(front.state.manDis()))));

			nextState =  front.state.move_down();
			if (nextState != null)
				queueOfStates.add(new Node(nextState, front,front.g_n+1,front.state.manDis(),((front.g_n)+(front.state.manDis()))));

			nextState =  front.state.move_left();
			if (nextState != null)
				queueOfStates.add(new Node(nextState, front,front.g_n+1,front.state.manDis(),((front.g_n)+(front.state.manDis()))));

			nextState =  front.state.move_right();
			if (nextState != null)
				queueOfStates.add(new Node(nextState, front,front.g_n+1,front.state.manDis(),((front.g_n)+(front.state.manDis()))));
		}

		return null;
	}

    Node() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

	public String toString() {
		return state + "\n->>>:  "  + "\n";
	}

	public static void print_matrix(Node n) {
           

		if (n != null) {
                        
			print_matrix(n.parent);
                       // System.out.println("Serial: "+serial);
			System.out.println("Manhattan Distance Of The State: "+n.state.manDis());
                        System.out.println("g(n) Cost Of The State :"+n.g_n);
                        System.out.println("f(n) Cost Of The State :"+n.f_n);
			System.out.println(n);
                        System.out.println("--------------------Parent State---------------");
                        System.out.println(n.parent);
                        
                        n=n.parent;
		}
	}


	public static class MyComparator implements Comparator<Node> {
		@Override
		public int compare(Node o1, Node o2) {
			if(o1.g_n > o2.g_n){
				return 1;
			}
			else if (o1.g_n < o2.g_n){
				return -1;
			}
			else{
				return 0;
			}
		}
	}
}

